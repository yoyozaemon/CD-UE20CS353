int main()
{
	int a=5;
	float b=4.6;
	double c=6.9845;
	char d="c";
	a=2;
	int b;
}
	