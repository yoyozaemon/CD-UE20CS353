#include<stdio.h>
int main()
{
int a[2][3];
int c[6][][7][8]
}
