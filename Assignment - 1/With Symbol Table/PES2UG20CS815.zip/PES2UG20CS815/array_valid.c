#include<stdio.h>
int main()
{
int a[2][3];
int b[2];
int c[6][6][7][8]; 
}