#include<stdio.h>
int main()
{
int i=0;
do
{
i++;
}while(i>10);
}