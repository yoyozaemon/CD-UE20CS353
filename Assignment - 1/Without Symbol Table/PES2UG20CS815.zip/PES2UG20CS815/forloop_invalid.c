#include<stdio.h>
int min()
{
int count = 0;
for(int i = 0 ; i < 20 ; i++)
{
count++;
}
return 0;
}